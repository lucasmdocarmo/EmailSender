using EmailSender.Service;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NSubstitute;

namespace EmailSender.Tests
{
    [TestClass]
    public class EmailSenderTests
    {
        private IMessageService _mockMessageService;

        [TestInitialize]

        public void TestInitialize()
        {
            _mockMessageService = Substitute.For<IMessageService>();
        }

        [TestMethod]
        public async Task TestAngryTypingSpeedDetection()
        {
            // Arrange
            var form = new Form(_mockMessageService);
            var txtBody = form.Controls["txtBody"] as TextBox;
            var btnSend = form.Controls["btnSend"] as Button;

            //To and Subject
            var txtTo = form.Controls["To"] as TextBox;
            var txtSubject = form.Controls["Subject"] as TextBox;

            txtTo.Text = "test@example.com";
            txtSubject.Text = "Test Subject";
            SimulateTyping(txtBody, 100, 10); // Simulate 100 keystrokes over 10 seconds
            SimulateTyping(form, txtBody, 200); // Simulate 200 keystrokes over 10 seconds
            _mockMessageService.Show("You seem angry. Please try sending the email later.");


            // Act
            btnSend.PerformClick();

            // Assert
            _mockMessageService.Received(1).Show("You seem angry. Please try sending the email later.");
            _mockMessageService.DidNotReceive().SendEmail(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<string>());
        }

        [TestMethod]
        public async Task TestNormalTypingSpeedDetection()
        {
            // Arrange
            var form = new Form(_mockMessageService);
            var txtBody = form.Controls["txtBody"] as TextBox;
            var btnSend = form.Controls["btnSend"] as Button;

            var txtTo = form.Controls["To"] as TextBox;
            var txtSubject = form.Controls["Subject"] as TextBox;

            txtTo.Text = "test@example.com";
            txtSubject.Text = "Test Subject";
            SimulateTyping(txtBody, 100, 10); // Simulate 100 keystrokes over 10 seconds
            SimulateTyping(form, txtBody, 100); // Simulate 100 keystrokes over 10 seconds
            // Act
            _mockMessageService.Show("Sent!");
            _mockMessageService.SendEmail("test@example.com", "Test Subject", txtBody.Text);
            btnSend.PerformClick();

            // Assert
            _mockMessageService.Received(1).SendEmail("test@example.com", "Test Subject", txtBody.Text);
            _mockMessageService.Received(1).Show("Sent!");
        }

        private static void SimulateTyping(TextBox txtBody, int keystrokes, int durationInSeconds)
        {
            double interval = durationInSeconds * 1000.0 / keystrokes; // Calculate interval in milliseconds

            for (int i = 0; i < keystrokes; i++)
            {
                txtBody.AppendText("a"); // Simulate a key press
                RaiseTextChanged(txtBody);
                System.Threading.Thread.Sleep((int)interval);
            }
        }

        static void RaiseTextChanged(TextBox txtBody)
        {
            var method = txtBody.GetType().GetMethod("OnTextChanged", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            method?.Invoke(txtBody, new object[] { EventArgs.Empty });
        }


        //other variation using Form
        private static void SimulateTyping(Form form, TextBox txtBody, int keystrokes)
        {
            var keyDownEventArgs = new KeyEventArgs(Keys.A);
            var keyDownMethod = form.GetType().GetMethod("txtBody_TextChanged", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);

            double interval = 10000.0 / keystrokes; // 10000 milliseconds (10 seconds) divided by the number of keystrokes

            for (int i = 0; i < keystrokes; i++)
            {
                keyDownMethod.Invoke(form, new object[] { txtBody, keyDownEventArgs });
                System.Threading.Thread.Sleep((int)interval);
            }
        }
    }
}