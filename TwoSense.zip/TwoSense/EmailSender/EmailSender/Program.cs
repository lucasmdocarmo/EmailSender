using EmailSender.Service;
using Microsoft.Extensions.DependencyInjection;

namespace EmailSender
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            var serviceCollection = new ServiceCollection();
            ConfigureServices(serviceCollection);
            using var serviceProvider = serviceCollection.BuildServiceProvider();
            ApplicationConfiguration.Initialize();
            var form = serviceProvider.GetRequiredService<Form>();

            Application.Run(form);
        }
        private static void ConfigureServices(IServiceCollection services)
        {
            services.AddScoped<IMessageService, MessageService>();
            services.AddScoped<Form>();
        }
    }
}