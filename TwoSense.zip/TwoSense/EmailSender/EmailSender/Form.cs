using EmailSender.Service;
using System.Diagnostics;

namespace EmailSender
{
    public partial class Form : System.Windows.Forms.Form
    {
        private readonly IMessageService _messageService;
        private Stopwatch _stopwatch;
        private int _keystrokes;
        public Form(IMessageService messageService)
        {
            InitializeComponent();
            _stopwatch = new Stopwatch();
            _messageService = messageService;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (_stopwatch.IsRunning)
            {
                _stopwatch.Stop();
            }

            double minutes = _stopwatch.Elapsed.TotalMinutes;
            double typingSpeed = minutes > 0 ? _keystrokes / minutes : 0;

            string message;
            if (typingSpeed > 400)
            {
                message = "You seem angry. Please try sending the email later.";
            }
            else
            {
                _messageService.SendEmail(To.Text, Subject.Text, txtBody.Text);
                message = "Sent!";
            }

            _messageService.Show(message);
            this.Tag = message;

            // Reset for next email
            _stopwatch.Reset();
            _keystrokes = 0;
        }

        private void txtBody_TextChanged(object sender, EventArgs e)
        {
            if (!_stopwatch.IsRunning)
            {
                _stopwatch.Start();
            }
            _keystrokes++;
        }
    }
}
