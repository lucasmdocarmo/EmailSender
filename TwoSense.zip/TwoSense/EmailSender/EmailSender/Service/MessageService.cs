﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailSender.Service
{
    public interface IMessageService
    {
        void Show(string message);
        void SendEmail(string to, string subject, string body);
    }

    public class MessageService : IMessageService
    {
        public void Show(string message)
        {
            MessageBox.Show(message);
        }
        public void SendEmail(string to, string subject, string body)
        {
            // Implement actual email sending logic here
            MessageBox.Show($"Email sent to: {to}\nSubject: {subject}\nBody: {body}");
        }
    }
}
