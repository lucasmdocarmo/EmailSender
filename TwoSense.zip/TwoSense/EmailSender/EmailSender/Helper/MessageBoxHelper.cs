﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailSender.Helper
{
    public static class MessageBoxHelper
    {
        public static string LastMessage { get; private set; }

        public static DialogResult Show(string message)
        {
            LastMessage = message;
            return DialogResult.OK;
        }
    }
}
